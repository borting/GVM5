class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users, :options => 'ENGINE=InnoDB DEFAULT CHARSET=utf8' do |t|
      t.string :name
      t.string :username
      t.string :hashed_pw
      t.string :salt
      t.string :email

      t.timestamps
    end
  end
end
