class CreateAppLists < ActiveRecord::Migration
  def change
    create_table :app_lists, :options => 'ENGINE=InnoDB DEFAULT CHARSET=utf8' do |t|
      t.integer :vm_list_id
      t.string :app_name
      t.integer :port

      t.timestamps
    end
  end
end
