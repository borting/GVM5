class CreateVmLists < ActiveRecord::Migration
  def change
    create_table :vm_lists, :options => 'ENGINE=InnoDB DEFAULT CHARSET=utf8' do |t|
      t.integer :user_id
      t.integer :serial_no
      t.string  :ip
      t.boolean :available

      t.timestamps
    end
  end
end
