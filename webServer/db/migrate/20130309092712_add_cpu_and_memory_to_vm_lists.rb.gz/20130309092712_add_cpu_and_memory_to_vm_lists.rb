class AddCpuAndMemoryToVmLists < ActiveRecord::Migration
  def change
    add_column :vm_lists, :cpu, :integer
    add_column :vm_lists, :memory, :integer
  end
end
