class ChangeAppNameToAppNameId < ActiveRecord::Migration

  def change
    remove_column :app_lists, :app_name
    add_column :app_lists, :app_name_id, :integer
  end
end
