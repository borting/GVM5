class AddAbbrToAppNames < ActiveRecord::Migration
  def change
     add_column :app_names, :abbr, :string
  end
end
